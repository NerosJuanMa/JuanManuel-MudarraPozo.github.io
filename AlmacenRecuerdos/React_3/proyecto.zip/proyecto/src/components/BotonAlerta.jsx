function BotonAlerta() {
    return (
        <button onClick={() => alert("¡Hola! Has hecho clic.")}>
            Haz clic aquí
        </button>
    );
}
export default BotonAlerta;