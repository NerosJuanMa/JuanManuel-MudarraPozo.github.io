
export default function Inicio() {
  return (
    <>   
       <br /><br /><br /><br /><br /><br />  
   <h1>Prueba inicio</h1>
    </>
    )
}